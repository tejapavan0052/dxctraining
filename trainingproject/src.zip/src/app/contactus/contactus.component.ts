import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ContactDetails } from '../models/contact-details.model';
import { ContactDaoService } from '../services/contact-dao.service';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

  
  constructor(private contserv:ContactDaoService,private rout:Router) { }
  contactDetails:ContactDetails={"firstName":"","lastName":"","emailId":"","phoneNumber":0,"message":""};

  message="";

  ngOnInit(): void {
  }



  
saveContactCust()
{
  //console.log("check")
  if (typeof this.contactDetails.firstName === 'undefined' || typeof this.contactDetails.emailId === 'undefined' || typeof this.contactDetails.phoneNumber === 'undefined' || typeof this.contactDetails.message === 'undefined')
  {

     //console.log("details must not be empty")
   
   
     this.message += 'Details must not be empty';
    alert(this.message);
    console.log(this.message);
   window.location.reload()
   
}
else
{

    this.contserv.saveContactCust(this.contactDetails).subscribe(
        data=>console.log(data),
        error=>console.log(error)
        );
        this.message += "Message sent successfully! We'll be in touch with you soon!";
              alert(this.message);

              location.reload();

              // this.rout.navigate(['/contactus']);

            
        // this.rout.navigateByUrl('contactus');
        //window.location.reload()
  

}

}



}
