


export class Customer {

    userName:string;
    password: string;
    email: string;
    name:string;
    age: number;
    gender:string;
    address:string;

}


