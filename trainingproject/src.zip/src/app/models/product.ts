
export class Product {
  prodId: number;
  prodName: string;
  descp: string;
  price: number;
  imgUrl: string;

  constructor(prodId=0, prodName='', descp = '', price = 0, imgUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR608TWmLRWFNYPlY5xgKkgZPYe7mwv0GDMDtAS9nRdlVo4aytG') {
    this.prodId = prodId
    this.prodName = prodName
    this.descp = descp
    this.price = price
    this.imgUrl = imgUrl
    
  }


}
