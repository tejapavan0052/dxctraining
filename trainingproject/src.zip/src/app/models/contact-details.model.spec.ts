import { ContactDetails } from './contact-details.model';

describe('ContactDetails', () => {
  it('should create an instance', () => {
    expect(new ContactDetails()).toBeTruthy();
  });
});
