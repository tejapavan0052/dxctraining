import { Product } from './product';

export class CartItem {
  prodId: number;
  productId: number;
  productName: string;
  qty: number;
  price: number;
  total:number=0;

  constructor(prodId: number, product: Product, qty = 1) {
    this.prodId = prodId;
    this.productId = product.prodId;
    this.productName = product.prodName;
    this.price = product.price;
    this.qty = qty;
  }
}
