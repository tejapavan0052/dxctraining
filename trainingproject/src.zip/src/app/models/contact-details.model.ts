

export class ContactDetails {

    firstName:string;
    lastName:string;
    emailId:string;
    phoneNumber:number;
    message:string;
}
