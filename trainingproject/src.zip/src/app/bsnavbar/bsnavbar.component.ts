import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bsnavbar',
  templateUrl: './bsnavbar.component.html',
  styleUrls: ['./bsnavbar.component.css']
})
export class BsnavbarComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

 

    uname=localStorage.getItem('username');

    lgin=localStorage.getItem('login');




  lgout()
  {
    // localStorage.setItem("login","");
    // localStorage.setItem("username","Username");

    localStorage.removeItem("username");
    
    localStorage.setItem("username","");
    localStorage.removeItem("login");
    localStorage.setItem("login","");
         
        this.router.navigateByUrl('');
        window.location.reload();


  }


}
