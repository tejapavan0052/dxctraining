import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { Product } from 'src/app/models/product';
import { CartComponent } from '../cart.component';

@Component({
  selector: 'app-cart-item',
  templateUrl: './cart-item.component.html',
  styleUrls: ['./cart-item.component.css']
})
export class CartItemComponent implements OnInit {

  @Input() cartItem: any




  // @Input() product: Product

  // @Output() nameUpdate: EventEmitter<string> = new EventEmitter<string>();
  // updateParent(name){
  //   this.nameUpdate.emit(name)
  // }





  constructor() { }

  ngOnInit() {
  }

  incrQty() {
    // for (let i in this.cartItem) {
    // if (this.cartItem[i].productId === this.product.prodId) {
    //   this.cartItem[i].qty++
    //   break;

    let idx=1;

    while(1)
    {
      return idx++;
      
    }

    
  }

count=1;



qnty:number=0;
qt:number=0;


//productSubTotal=[];
//prodCtr=0;

i=0;




incrQnty() {
  if(this.i!=10000)
  {
    this.i++;
    this.qnty=this.i;
    this.qt=this.qnty;

    localStorage.setItem("qt",JSON.stringify(this.qt));


this.cartItem.total =(this.qnty * this.cartItem.price);
console.log(this.cartItem.total); 

localStorage.setItem("total",JSON.stringify(this.cartItem.total));

console.log("icr "+this.qt);
  }

}



decrQnty() {
  if(this.i!=0)
  {
    this.i--;
    this.qnty=this.i;
    this.qt=this.qnty;


    localStorage.setItem("qt",JSON.stringify(this.qt));
    console.log("decr "+this.qt);

    
  }
}














// ng = 'Angular'
// myName = 'Neo'


// upCase(st:string): void { console.log("heloo") }












// gthr=0;


// gp(qnty) {
//  this.gthr=this.qnty;
// }




// @Input() qtt:number;

// @Input() this.qt:number;


// @Input() decrQnty:any;
// @Output() outp=new EventEmitter<string>();




// public pickDate(date: any): void {
//   this.outp.emit(date);
// }

// qtyy:number=0;
// cartTotal:number=0;

// tt() {
// this.cartTotal = 0
// this.cartItem.forEach(item => {
//   this.cartTotal += (this.qtyy * item.price)

// }
// }









}
