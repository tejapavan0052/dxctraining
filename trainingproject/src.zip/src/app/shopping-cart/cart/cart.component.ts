import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MessengerService } from 'src/app/services/messenger.service'
import { Product } from 'src/app/models/product';
// import { CartService } from 'src/app/services/cart.service';
import { CartItem } from 'src/app/models/cart-item';
import { CartItemComponent } from './cart-item/cart-item.component';
import { Router } from '@angular/router';



@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {


  cartItems = [];

  cartTotal = 0

  constructor(private msg: MessengerService,private rout:Router) { }

  ngOnInit() {
    // this.handleSubscription();
    // this.loadCartItems();

    this.msg.getMsg().subscribe((product: Product) => {
      this.addProductToCart(product)

      // this.incr(product)
    })

  }


  emptyStorage()
{
  localStorage.clear()
}

  qt=JSON.parse(localStorage.getItem("qt"));
  
  total=JSON.parse(localStorage.getItem("total"));


  addProductToCart(product: Product) {

    let productExists = false

    // for (let i in this.cartItems) {
    //   if (this.cartItems[i].productId === product.prodId) {
    //     this.cartItems[i].qty++
    //     productExists = true
    //     break;
    //   }
    // }

    if (!productExists) {
      this.cartItems.push({
        productId: product.prodId,
        productName: product.prodName,
        qty: 1,
        price: product.price
      })
    }
    

    this.cartTotal = 0
    this.cartItems.forEach(item => {
      // this.cartTotal += (item.qty * item.price)

      console.log(this.qt);
      this.cartTotal += (this.qt * item.price)



    // if (this.cartItems.length === 0) {
    //   this.cartItems.push({
    //     productId: product.id,
    //     productName: product.name,
    //     qty: 1,
    //     price: product.price
    //   })
    // } else {
    //   for (let i in this.cartItems) {
    //     if (this.cartItems[i].productId === product.id) {
    //       this.cartItems[i].qty++
    //     } else {
    //       this.cartItems.push({
    //         productId: product.id,
    //         productName: product.name,
    //         qty: 1,
    //         price: product.price
    //       })
    //     }
    //   }
    // }

    


    })
  }

  

  
checkout(cartTotal) {
  return this.tot=this.cartTotal;
  console.log("tot"+this.tot);
}


isCartEmpty(cartTotal) {
  if(cartTotal>0) {
    return true;
  }
}
 

ccnumber:string;
ccname:string;
cccvc:string;
ccexp:string;
msg2="";

onPay() {


  if(this.ccnumber != 'undefined' && this.ccname != 'undefined' && this.ccexp != 'undefined' && this.cccvc != 'undefined' ) {
  this.msg2  += "Order has been placed successfully!!";
  alert(this.msg2);

  // this.rout.navigateByUrl('');


  this.rout.navigate([''])
  .then(() => {
    window.location.reload();
  });

}


}


tot:number=0;

// get totalItemsCount() {
//   let count=0;
//   for(let productId in this.cartItems)
//     count+=this.cartItems[productId].quantity;
//   return count;
// }


// incr(product:Product) {
//   let productExists = false

//   for (let i in this.cartItems) {
//   if (this.cartItems[i].productId === product.prodId) {
//   this.cartItems[i].qty++
//   productExists = true
//   break;
// }
// }
// }




}









  // handleSubscription() {
  //   this.msg.getMsg().subscribe((product: Product) => {
  //     this.loadCartItems();
  //   })
  // }

  // loadCartItems() {
  //   this.cartService.getCartItems().subscribe((items: CartItem[]) => {
  //     this.cartItems = items;
  //     this.calcCartTotal();
  //   })
  // }

  // calcCartTotal() {
  //   this.cartTotal = 0
  //   this.cartItems.forEach(item => {
  //     this.cartTotal += (item.qty * item.price)
  //   })
  // }


