import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BsnavbarComponent } from './bsnavbar/bsnavbar.component';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';

import { OrderSuccessComponent } from './order-success/order-success.component';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { LogoutComponent } from './logout/logout.component';
import { FruitsComponent } from './fruits/fruits.component';
import { ItemsComponent } from './items/items.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { MessengerService } from './services/messenger.service';
import { ProductService } from './services/product.service';
import { CartComponent } from './shopping-cart/cart/cart.component';
import { CartItemComponent } from './shopping-cart/cart/cart-item/cart-item.component';
import { FiltersComponent } from './shopping-cart/filters/filters.component';
import { ProductListComponent } from './shopping-cart/product-list/product-list.component';
import { ProductItemComponent } from './shopping-cart/product-list/product-item/product-item.component';
import { RegistrationComponent } from './registration/registration.component';
import { AdminComponent } from './admin/admin.component';
import { Customer } from './models/customer.model';
import { UserDetailsComponent } from './admin/user-details/user-details.component';
import { DelProdsComponent } from './admin/del-prods/del-prods.component';
import { ProdDetailsComponent } from './admin/prod-details/prod-details.component';


// import { VegComponent } from './veg/veg.component';
// import { MyOrdersComponent } from './my-orders/my-orders.component';
// import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
// import { CheckoutComponent } from './checkout/checkout.component';
// import { BeveragesComponent } from './beverages/beverages.component';
// import { CandhComponent } from './candh/candh.component';
// import { TeacoffeeComponent } from './teacoffee/teacoffee.component';
// import { HygproductsComponent } from './hygproducts/hygproducts.component';

@NgModule({
  declarations: [
    AppComponent,
    BsnavbarComponent,
    HomeComponent,
    ProductsComponent,
    OrderSuccessComponent,
    LoginComponent,
    ContactusComponent,
    AboutusComponent,
    LogoutComponent,
    FruitsComponent,
    ItemsComponent,
    ShoppingCartComponent,
    CartComponent,
    CartItemComponent,
    CartComponent,
    FiltersComponent,
    ProductListComponent,
    ProductItemComponent,
    RegistrationComponent,
    AdminComponent,
    UserDetailsComponent,
    DelProdsComponent,
    ProdDetailsComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [
    MessengerService,
    ProductService,
    Customer
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
