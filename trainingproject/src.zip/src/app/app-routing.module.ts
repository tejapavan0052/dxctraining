import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminComponent } from './admin/admin.component';
import { DelProdsComponent } from './admin/del-prods/del-prods.component';
import { ProdDetailsComponent } from './admin/prod-details/prod-details.component';
import { UserDetailsComponent } from './admin/user-details/user-details.component';

import { ContactusComponent } from './contactus/contactus.component';
import { FruitsComponent } from './fruits/fruits.component';
import { HomeComponent } from './home/home.component';
import { ItemsComponent } from './items/items.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { CartItem } from './models/cart-item';

import { OrderSuccessComponent } from './order-success/order-success.component';
import { ProductsComponent } from './products/products.component';
import { RegistrationComponent } from './registration/registration.component';
import { CartComponent } from './shopping-cart/cart/cart.component';
import { FiltersComponent } from './shopping-cart/filters/filters.component';
import { ProductItemComponent } from './shopping-cart/product-list/product-item/product-item.component';
import { ProductListComponent } from './shopping-cart/product-list/product-list.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';

// import { BeveragesComponent } from './beverages/beverages.component';
// import { CandhComponent } from './candh/candh.component';
// import { CheckoutComponent } from './checkout/checkout.component';
// import { HygproductsComponent } from './hygproducts/hygproducts.component';
// import { MyOrdersComponent } from './my-orders/my-orders.component';
// import { TeacoffeeComponent } from './teacoffee/teacoffee.component';
// import { VegComponent } from './veg/veg.component';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'products', component: ProductsComponent },
  // { path: 'checkout', component:CheckoutComponent },
  { path: 'order-success', component:OrderSuccessComponent },
  { path: 'contactus', component:ContactusComponent },
  { path: 'aboutus', component:AboutusComponent },
  { path: 'login', component:LoginComponent },
  { path: 'logout', component:LogoutComponent },
  { path: 'fruits', component:FruitsComponent },
  { path: 'items', component:ItemsComponent },

  { path: 'shoppy', component:ShoppingCartComponent },
  { path: 'userdetails', component:UserDetailsComponent },
  { path: 'delprods', component:DelProdsComponent },


  

  {path:'admin',component:AdminComponent,
  children:[
    {path:'admin/getAllProducts', component:  ProdDetailsComponent },
    {path:'admin/delete',component:DelProdsComponent },
    {path:'admin/getAllUsers', component:  UserDetailsComponent }
  ]},


  { path: 'registration', component:RegistrationComponent }




  // {
  //   path:'shoppingcart',component:ShoppingCartComponent,
  //   children:[
  //     {path:'shoppingcart/filters',component:FiltersComponent},
  //     {path:'shoppingcart/cart',component:CartComponent},
  //     {path:'shoppingcart/product-list',component:ProductListComponent}

  //   ]
  // },


  // {
  //   path:'cart',component:CartComponent,
  //   children:[
  //     {path:'cart/cart-item',component:CartItem}

  //   ]
  // },



  // {
  //   path:'product-list',component:ProductListComponent,
  //   children:[
  //     {path:'product-list/product-item',component:ProductItemComponent}

  //   ]
  // },



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
