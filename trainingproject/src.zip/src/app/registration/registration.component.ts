import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../models/customer.model';
import { CustomerDaoService } from '../services/customer-dao.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  message="";

  constructor(private customerserv:CustomerDaoService,private rout:Router) { }

  ngOnInit(): void {
  }


  customer:Customer={"userName":"","password":"","email":"" ,"name":"","age":0,"gender":"","address":""};


saveCustomer()
{
  //console.log("check")
  if (typeof this.customer.userName === 'undefined' || typeof this.customer.password === 'undefined' || typeof this.customer.email === 'undefined' || typeof this.customer.name === 'undefined' || typeof this.customer.gender === 'undefined' || typeof this.customer.address === 'undefined' || this.customer.age===0)
  {

     //console.log("details must not be empty")
   
   
     this.message += 'Details must not be empty';
    alert(this.message);
    console.log(this.message);
   window.location.reload()
   
}
else
{

    this.customerserv.saveCustomer(this.customer).subscribe(
        data=>console.log(data),
        error=>console.log(error)
        );
        this.message += 'Successfully Registered';
              alert(this.message);
            
        // this.rout.navigateByUrl('login');
        window.location.reload();
  

}

}

}
