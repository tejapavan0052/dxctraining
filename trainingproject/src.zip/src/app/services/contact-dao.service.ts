import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ContactDetails } from '../models/contact-details.model';

@Injectable({
  providedIn: 'root'
})
export class ContactDaoService {
 
  constructor(private http:HttpClient) { }


  getContactCust(emailId:string)
  {
    return this.http.get<ContactDetails>(`http://localhost:1112/contactcust/${emailId}`)
  }

  saveContactCust(contactcust:ContactDetails)
  {
    return this.http.post<any>('http://localhost:1112/contactcust',contactcust);
  }






  getAllContactCusts()
  {
    return this.http.get<ContactDetails>('http://localhost:1112/contactcust')
  }



 




}
