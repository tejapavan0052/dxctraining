import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from '../models/customer.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerDaoService {
  
  constructor(private http:HttpClient) { }

  getCustomer(userName:string)
  {
    return this.http.get<Customer>(`http://localhost:1112/customer/${userName}`)
  }

  saveCustomer(customer:Customer)
  {
    return this.http.post<any>('http://localhost:1112/customer',customer);
  }






  getAllCustomers()
  {
    return this.http.get<Customer>('http://localhost:1112/customers')
  }



  deletebyUsername(userName:string)
  {
    return this.http.delete<Customer>(`http://localhost:1112/customer/${userName}`)
  }





}
