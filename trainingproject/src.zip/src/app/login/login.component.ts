import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../models/customer.model';
import { CustomerDaoService } from '../services/customer-dao.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})




export class LoginComponent implements OnInit {

  userName:string;
  password:string;
  errorMessage="";


  constructor(private customerserv:CustomerDaoService,private rout:Router) { }
  customer:Customer={"userName":"","password":"","email":"","name":"","age":0,"gender":"","address":""};
  ngOnInit(): void {
  }

  validate()
  {
    if (typeof this.userName === 'undefined' && typeof this.password === 'undefined') {
      this.errorMessage += 'Credentials must not be empty';
      alert(this.errorMessage);
      window.location.reload()
   
  }
  else if (typeof this.userName === 'undefined' && !(typeof this.password === 'undefined')) {
    this.errorMessage += 'Username must not be empty!';
    alert(this.errorMessage);
    window.location.reload()
}
 else if (typeof this.password === 'undefined' && !(typeof this.userName === 'undefined')) {
  this.errorMessage += 'Password must not be empty!';
  alert(this.errorMessage);
  window.location.reload()
}
else if(this.userName==='admin@dxc.com' && this.password==='admin')
    {
      localStorage.setItem("username",this.userName);
      localStorage.setItem("login","true");
      //this.rout.navigateByUrl('admin');
    }

    else
    {

    this.customerserv.getCustomer(this.userName).subscribe(
      data=>{this.customer=data;

    if(this.customer.userName==this.userName && this.customer.password==this.password)
    {
      
     localStorage.setItem("username",this.userName);
     localStorage.setItem("login","true");
      //  location.reload()
      // this.rout.navigateByUrl('');


      this.rout.navigate([''])
      .then(() => {
        window.location.reload();
      });

    }
    else
   {
    this.errorMessage+="Invalid username or Password";
      alert(this.errorMessage);
      window.location.reload()

   }
   


      },
      error=>console.log(error)
    );

    }
  }

}

