import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from 'src/app/models/product';
import { ProductService } from 'src/app/services/product.service';
import { ProdDetailsComponent } from '../prod-details/prod-details.component';

@Component({
  selector: 'app-del-prods',
  templateUrl: './del-prods.component.html',
  styleUrls: ['./del-prods.component.css']
})
export class DelProdsComponent implements OnInit {

  
  constructor(private prodserv:ProductService,private rout:Router) { }
  product:Product={"prodName":"","prodId":0,"descp":"","price":0,"imgUrl":""};  
  check=false;

  ngOnInit() {
    if(localStorage.getItem("login")==="")
    {
      this.rout.navigateByUrl('/login');
    }
  }

  // search()
  // {
  //   this.prodserv.getProdByName(this.product.prodName).subscribe(
  //     data=>this.product=data,
  //     error=>console.log(error)
  //   );

  //   console.log(this.product.prodName);
  //   if(this.product.prodName!="")
  //   {
  //     this.check=true;
  //   }
  // }

  deleteProdByName()
  {
    this.prodserv.deleteProdByName(this.product.prodName).subscribe(
      data=>console.log(data),
      error=>console.log(error)
    );
    alert("Product Deleted");
    this.rout.navigateByUrl('admin');
    
  }





}
