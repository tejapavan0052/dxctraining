import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DelProdsComponent } from './del-prods.component';

describe('DelProdsComponent', () => {
  let component: DelProdsComponent;
  let fixture: ComponentFixture<DelProdsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DelProdsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DelProdsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
