import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/models/customer.model';
import { CustomerDaoService } from 'src/app/services/customer-dao.service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  constructor(private custserv:CustomerDaoService,private rout: Router) { }

  // customer:Customer[]=[];

  customer:Customer={"userName":"","password":"","name":"","email":"","age":0,"gender":"","address":""}; 

  ngOnInit() {
    if(localStorage.getItem("login")==="")
    {
      this.rout.navigateByUrl('/login');
    }
    
      this.custserv.getAllCustomers().subscribe(
        data =>this.customer=data,
        // data=>console.log(data),
        error=>console.log(error)
      );
    
  }



}
